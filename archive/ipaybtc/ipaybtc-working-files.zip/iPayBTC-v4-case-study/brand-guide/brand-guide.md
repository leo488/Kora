# iPayBTC Brand Guide v0.1 — text and rules

Transcribed from "Guide V 0.1 (test).pdf" (Google Drive, Sep 2026). The PDF itself (22 MB) holds the images: logo artwork, mockups, the home-screen sample. Put the PDF in this folder as `iPayBTC-Brand-Guide-v0.1.pdf` before handing the package to Claude Code.

Drive: https://drive.google.com/file/d/1gIe3YINvKjskDVO__QVSZnOz30Bq7Sug/view

## Who we are

iPayBTC is a Bitcoin-first platform built to make real Bitcoin use simple, fast and accessible to everyone. We're reimagining how money moves: open, borderless, and owned by the people. Bitcoin is more than an asset; it's financial freedom in motion.

**Brand story.** iPayBTC was born from one belief: Bitcoin should feel easy. Not technical. Not intimidating. Not hidden behind complex wallets or confusing interfaces. Everyday people still couldn't use Bitcoin the way they use cash or mobile banking. So iPayBTC is the opposite of that: paying with Bitcoin feels natural, you send value instantly, transparency is obvious, and you always understand what's happening and why.

- **Mission:** make Bitcoin simple, fast and accessible for everyone, through clear design, reliable technology and seamless everyday use.
- **Vision:** a world where Bitcoin is effortless to use, trusted by millions, and woven into daily life as the simplest way to pay.
- **Essence:** "Freedom in Motion." Bitcoin made simple.
- **Values:** Freedom, Trust, Accessibility, Community, Empowerment.
- **Taglines in use:** "Bitcoin for Everyday Life." · "Own it. Spend it. Learn it." · "Spend Bitcoin like money, for everyday use" · "Powering your everyday with Bitcoin."

## Logo

- Wordmark plus the signature icon: an abstract Bitcoin coin in motion, an elongated, tilted oval ("a coin caught mid-spin"). It represents speed, flow and forward movement.
- Primary logo (horizontal) is the default; icon-only for app icons, badges, favicons, watermarks, loading indicators.
- Colour modes: Deep Navy logo on light backgrounds; Electric Blue logo for energetic/marketing uses; white on dark.
- Clear space: 0.5× the height of the "i". Partner spacing: 1× the oval's height.
- Minimum size: 38 px digital, 15 mm print; social: never below 40 px.
- Don'ts: stretch, recolour, add effects (shadows, glows, bevels, outlines, 3D, textures), rotate, place on low contrast or busy backgrounds, crop, alter spacing, redraw the icon, make new lockups. "Our logo is our most sacred asset."

## Colour

Core:
- **Deep Navy #050E7F** (HSL 236 92 26). Foundation of the brand; dominant background across product and hero layouts.
- **Electric Blue #0A31F5** (HSL 230 92 50). Highlights, accents, major UI elements, high-impact visuals.

Background system: Deep Navy #050E7F (primary), Electric Blue #0A31F5, Milky Bitcoin Yellow #FFF778 (alternative light background), Deep Blue #040246 (dramatic, premium, night mode, gradients).

Extended: Bitcoin Orange #FF8A00 (sparingly), Bright Yellow #FFF778, Sky Blue #4DA3FF and #88C2ED, Cream/Gold Yellow #F5E27A, Gold #F5BF0F.

Usage: "brutalist but clean". Two pastel tones can combine (Sky Blue background with Cream Yellow headline; Milky Yellow card on Pale Blue). Keep contrast so text is clear, use large type for structure, generous spacing; intentional, not messy. "Soft colours, bold structure."

## Typography

- **Headings: Neue Haas Grotesk** (Bold, tracking −10). Confident, direct, liberating.
- **Body and UI: Inter** (Regular, tracking 0). Calm, neutral, instructional.
- **Website headers, billboards, posters: Futura LT Condensed**, for energy and forward momentum.

## App screens (from the guide)

Neue Haas for headings, Inter for body. Generous white space, sharp hierarchy, intentional spacing; light, high-end, trustworthy. Home sample copy: "@Fadare!", "Good afternoon, Fadare", "Your Bitcoin is up 4.6% today", "$176,000.00", "0.000000565 BTC", "Tap to hide balance".

## Other touchpoints in the guide

Social media (pattern + typography; "Scan. Learn. Earn.", "Bitcoin Culture, Everywhere.", "Join the BTC Wave."), website headers and campaign messaging in Futura LT Condensed, posters ("Own Bitcoin. Own the Future.", "Join the Movement."), billboards ("Move Freely. Own Bitcoin.", "Join the BTC Movement Today."), merch (T-shirts, hoodies, tote bags, caps, water bottles; logo + motion pattern, short lines like "Pay in Freedom.", "Bitcoin, Everywhere.", "Carry Bitcoin Forward"), favicon.
