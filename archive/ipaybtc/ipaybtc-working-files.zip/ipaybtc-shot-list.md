# iPayBTC case study: shot list

Every grey panel on the page names one of these, in page order. "Loop" means a short muted video (MP4, 5 to 10 seconds, seamless). Everything else is a still. Deliver at least 3000px on the long edge, and 4K for the loops.

| # | Shot | Ratio | Still or loop |
|---|------|-------|---------------|
| 1 | Hero: 3D iPayBTC mark floating on a soft brand-colour field | 16:10 | Loop |
| 2 | Brand colour composition: big flat colour blocks | 16:9 | Loop |
| 3 | Hero 3D object, such as a Bitcoin vault or wallet, on a brand colour | 16:9 | Still (or slow turntable loop) |
| 4 | Colour band transition: thin stripes of the palette | 21:9 | Loop |
| 5 | Logo lockup: full wordmark on the primary brand colour | 16:9 | Still |
| 6 | Browser close-up: the iPayBTC website and address bar | 16:9 | Still or scroll loop |
| 7a | Phone: home screen with the iPayBTC app icon | 4:5 | Still |
| 7b | Hand holding a phone showing the pay or QR flow | 4:5 | Still |
| 8 | 3D icon family over a large brand line (supergraphic) | 16:9 | Still |
| 9 | Second brand colour composition | 16:9 | Loop |
| 10 | 3D icon family: six icons on a light ground | 16:9 | Still |
| 11a | Lifestyle photo: someone using the app in the real world | 4:5 | Still |
| 11b | Product detail: card or key screen up close | 4:5 | Still |
| 12 | Still life: phone on a desk | 16:9 | Still |
| 13a | Merch: cap | 1:1 | Still |
| 13b | Merch: tote bag | 1:1 | Still |
| 14 | Ten social posts (shown 5 across) | 4:5 each | Stills, a few can be loops |
| 15 | Web banner | 16:9 | Still or loop |
| 16 | Out-of-home: three posters at a bus shelter | 16:9 | Still |
| 17 | Ten portraits for the people collage | 3:4 each | Stills |
| 18 | Billboard: the campaign line in the city | 16:9 | Still |
| 19 | Logo sting: the mark animating on brand colour | 16:9 | Video |

**What to make in Blender:** 1, 3, 8, 10 and the mark for 19. Mockups (6, 7, 12, 13, 15, 16, 18) can come from mockup templates. 11 and 17 need a photographer or licensed stock.

## Connecting Blender

Blender MCP is an open-source add-on plus a small server that lets Claude drive Blender: create objects, set materials and lighting, and render. It runs on your own computer, alongside Blender.

1. In Blender, install the Blender MCP add-on (Edit > Preferences > Add-ons > Install from disk), then click "Connect to Claude" in its sidebar panel.
2. Add the Blender MCP server to Claude Desktop or Claude Code on the same computer. The add-on's README has the exact config snippet.
3. Open a chat there and ask for an asset. Claude builds it in your open Blender scene, and you export the renders.

This project thread runs in the cloud, so it can't reach Blender on your computer directly. Either use Claude Desktop on your machine for the 3D work and drop the renders here, or I can start a session on your computer from this thread once Blender MCP is set up there. I haven't tested the add-on myself, so check its README for the current install steps.
