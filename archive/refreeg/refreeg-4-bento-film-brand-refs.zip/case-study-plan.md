# Refreeg case study: frame plan

Follows Leo's reference (Remono case study) top to bottom, 15 plates, same stacked layout as the iPayBTC page.
"Have" = already in Leo's brand book. "Magnific" = new mockup I generate (needs Leo's OK). "Code" = I design it in Refreeg style (Recoleta + Geist, Refreeg Blue / Ink / Forest / Lime).

| # | Reference plate | Refreeg plate | Source |
|---|---|---|---|
| 1 | Logo on brand orange, full width | Refreeg logo on Refreeg Blue | Code (real logo file) |
| 2 | City billboard | "Give where you can see." billboard | Have (brand book p134) |
| 3 | Pair: phone close-up with app icon / person + profile card | Phone home screen with Refreeg app icon / person with a donation-receipt card | Magnific + Have (p124 photo) |
| 4 | Website on a city screen | Refreeg website on a big outdoor screen | Magnific blank screen + real web screen |
| 5 | Tablet on orange chair | Tablet with the admin dashboard on a blue surface | Magnific blank tablet + real admin screen |
| 6 | Pair: person with UI chip / app screen on blue | Person with "₦25,000 receipted" chip / campaign screen on Lime | Have (p126) + real app screen |
| 7 | Subway poster | "Every kobo. Accounted for." transit poster | Magnific blank poster + p135 artwork |
| 8 | Phone in jeans pocket | Phone with Refreeg mark in a pocket | Magnific |
| 9 | Pair: social post / person with chip | Instagram post design / person with receipt chip | Code + Have (p118) |
| 10 | Phone in hand with app | Hand holding phone with real app screen | Magnific blank phone + real screen |
| 11 | Tote on payphone | Forest tote | Have (p139) |
| 12 | Pair: shopper with chip / phone on green | Person with chip / app screen on Lime | Have (p126/p131) |
| 13 | Three posters on a wall | Three Refreeg posters on a wall | Magnific blank wall + posters designed in code |
| 14 | People at a table | Group photo (hands / circle) | Have (p113 or p120) |
| 15 | Big type statement | "Every naira, receipted." with brand icons | Code |

Magnific: 7 new images (plates 3, 4, 5, 7, 8, 10, 13), about 145 credits each at 4K, about 1,000 credits, 1,450 max with retries. Balance on Nov 14: 8,999.
