import cv2,numpy as np,sys
sys.path.insert(0,'../tools'); from warp import white_mask
from grade import warm
from PIL import Image,ImageDraw,ImageFont
rng=np.random.default_rng(11)
OUT='out'; import os; os.makedirs(OUT,exist_ok=True)
def grain(img,s=5.0):
    n=rng.normal(0,s,img.shape[:2]).astype(np.float32); n=cv2.GaussianBlur(n,(0,0),0.6)
    return np.clip(img.astype(np.float32)+n[...,None],0,255).astype(np.uint8)
def crop(img,ratio):
    H,W=img.shape[:2]
    if W/H>ratio: w=int(H*ratio); x=(W-w)//2; return img[:,x:x+w]
    h=int(W/ratio); y=(H-h)//2; return img[y:y+h]
R={}
def save(name,img,ratio,g=5.0,w=False):
    ratio=R.get(name,ratio); img=crop(img,ratio)
    if w: img=warm(img)
    img=grain(img,g)
    cv2.imwrite(f'{OUT}/{name}.jpg',img,[cv2.IMWRITE_JPEG_QUALITY,93]); print(name,img.shape)
def rgba(p): 
    a=cv2.imread(p,cv2.IMREAD_UNCHANGED)
    if a.shape[2]==3: a=np.dstack([a,np.full(a.shape[:2],255,np.uint8)])
    return a
def over(base,ov,x,y):
    h,w=ov.shape[:2]; a=ov[...,3:4].astype(np.float32)/255
    roi=base[y:y+h,x:x+w].astype(np.float32); base[y:y+h,x:x+w]=(roi*(1-a)+ov[...,:3]*a).astype(np.uint8)
def warp_into(base,ov,dst,mask,shade=True,blur=0.7):
    H,W=base.shape[:2]; h,w=ov.shape[:2]
    M=cv2.getPerspectiveTransform(np.float32([[0,0],[w,0],[w,h],[0,h]]),np.float32(dst))
    wa=cv2.warpPerspective(ov[...,:3],M,(W,H),flags=cv2.INTER_LANCZOS4)
    am=cv2.warpPerspective(ov[...,3] if ov.shape[2]==4 else np.full((h,w),255,np.uint8),M,(W,H))
    a=(np.minimum(am,mask).astype(np.float32)/255); a=cv2.GaussianBlur(a,(0,0),blur)[...,None]
    if shade:
        L=cv2.cvtColor(base,cv2.COLOR_BGR2GRAY).astype(np.float32); med=np.median(L[mask>0])
        sh=np.clip(cv2.GaussianBlur(L/med,(0,0),20),0.8,1.1)[...,None]; wa=np.clip(wa*sh,0,255)
    return (base*(1-a)+wa*a).astype(np.uint8)
def rot(ov,ang,scale=1.0):
    h,w=ov.shape[:2]; d=int(np.hypot(h,w)*scale)+4
    M=cv2.getRotationMatrix2D((w/2,h/2),ang,scale); M[0,2]+=d/2-w/2; M[1,2]+=d/2-h/2
    return cv2.warpAffine(ov,M,(d,d),flags=cv2.INTER_LANCZOS4,borderValue=(0,0,0,0))
def text_img(t,size,col=(255,255,255)):
    f=ImageFont.truetype('../geist/package/dist/fonts/geist-sans/Geist-Medium.ttf',size)
    b=f.getbbox(t); im=Image.new('RGBA',(b[2]+20,b[3]+20),(0,0,0,0)); ImageDraw.Draw(im).text((10,10),t,font=f,fill=col+(255,))
    return cv2.cvtColor(np.array(im),cv2.COLOR_RGBA2BGRA)
mk=rgba('d/mk.png'); ys,xs=np.nonzero(mk[...,3]>8); mk=mk[ys.min():ys.max()+1,xs.min():xs.max()+1]; pd=40; mk=cv2.copyMakeBorder(mk,pd,pd,pd,pd,cv2.BORDER_CONSTANT,value=(0,0,0,0))
def place_center(base,ov,cx,cy): over(base,ov,int(cx-ov.shape[1]/2),int(cy-ov.shape[0]/2))
R.update({'rf-billboard':2.0,'rf-phone-icon':0.8,'rf-p3b':0.8,'rf-web':16/9,'rf-tablet':1.5,'rf-folders':0.8,'rf-p6b':0.8,'rf-subway':2.0,'rf-pocket':16/9,'rf-p9a':0.8,'rf-lunch':0.8,'rf-scooter':2.0,'rf-tote':1.5,'rf-groceries':0.8,'rf-p12b':0.8,'rf-posters':2.2,'rf-family':16/9,'rf-p15':2.0})
# flat plates
for n,r in [('logo',875/447),('p3b',433/462),('p6b',433/486),('p9a',433/441),('p12b',433/449),('p15',875/487)]:
    save('rf-'+n,cv2.imread(f'd/{n}.png'),r,4.0)
for n,src,r in [('bb','rf-billboard',None)]: pass
# 3a icon
im=cv2.imread('s03a.png')
place_center(im,rot(cv2.resize(mk,(380,int(380*mk.shape[0]/mk.shape[1])),interpolation=cv2.INTER_AREA),67),2423,2836)
lab=text_img('Refreeg',112); place_center(im,rot(lab,67),2423+470,2836+200)
save('rf-phone-icon',im,433/462,w=True)
# 4 web
save('rf-web',cv2.imread('d/p4.png'),875/604)
# 5 tablet
im=cv2.imread('s05.png'); ai=rgba('d/ai.png'); ai=ai[:, ai.shape[1]-int(ai.shape[0]*1847/1539):]
m=cv2.erode(white_mask(im),np.ones((5,5),np.uint8))
im=warp_into(im,ai,[(2488,749),(3743,2104),(2450,2938),(1274,1458)],m)
save('rf-tablet',im,875/578,w=True)
# 6a, 9b, 12a chips
for src,chip,xy,name,r in [('s06a','c6',(560,1950),'rf-folders',433/486),('s09b','c9',(1750,2250),'rf-lunch',433/441),('s12a','c12',(380,1150),'rf-groceries',433/449)]:
    im=cv2.imread(src+'.png'); c=rgba(f'd/{chip}.png'); c=cv2.resize(c,(int(c.shape[1]*1.15),int(c.shape[0]*1.15)),interpolation=cv2.INTER_CUBIC)
    over(im,c,*xy); save(name,im,r,w=True)
# 7 subway
im=cv2.imread('s07.png'); h=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
m=((h[...,0]>105)&(h[...,0]<130)&(h[...,1]>150)&(h[...,2]>80)).astype(np.uint8)*255
m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((25,25),np.uint8))
im=warp_into(im,rgba('d/p7.png'),[(1395,514),(4303,504),(4300,2617),(1405,2617)],m)
save('rf-subway',im,875/480,w=True)
# 8 pocket
im=cv2.imread('s08.png'); h=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
m=((h[...,0]>105)&(h[...,0]<130)&(h[...,1]>150)&(h[...,2]>80)).astype(np.uint8)
ys,xs=np.nonzero(m); print('s08 center',xs.mean(),ys.mean())
ov=rot(cv2.resize(mk,(620,int(620*mk.shape[0]/mk.shape[1])),interpolation=cv2.INTER_AREA),40)
place_center(im,ov,int(xs.mean())-40,int(ys.mean())-60)
save('rf-pocket',im,875/483,w=True)
# 10 scooter phone
im=cv2.imread('s10.png'); pl=rgba('/mnt/project-files/kora/refreeg/figma/app-pledge-x4.png')
q=[(2642,267),(3492,469),(2972,2779),(2127,2507)]
w=np.hypot(850,202); hh=np.hypot(2127-2642,2507-267); pl=pl[:-6]; H2=int(pl.shape[1]*2.16)
pad=np.full((max(H2,pl.shape[0]),pl.shape[1],4),255,np.uint8); pad[:pl.shape[0]]=pl
m=cv2.erode(white_mask(im),np.ones((5,5),np.uint8))
im=warp_into(im,pad,q,m); save('rf-scooter',im,875/480,w=True)
# 13 posters
im=cv2.imread('s13.png'); h=cv2.cvtColor(im,cv2.COLOR_BGR2HSV)
def comp_mask(m):
    m=cv2.morphologyEx(m.astype(np.uint8)*255,cv2.MORPH_OPEN,np.ones((9,9),np.uint8))
    n,l,st,_=cv2.connectedComponentsWithStats(m);i=1+np.argmax(st[1:,4]);x,y,w,hh,_=st[i];return (l==i).astype(np.uint8)*255,(x,y,w,hh)
mb,bb=comp_mask((h[...,0]>105)&(h[...,0]<130)&(h[...,1]>150)&(h[...,2]>80))
ml,bl=comp_mask((h[...,0]>28)&(h[...,0]<45)&(h[...,1]>120)&(h[...,2]>150))
mw,bw=comp_mask((h[...,1]<40)&(h[...,2]>200)&(np.arange(h.shape[1])[None,:]>bb[0]+bb[2]+50)&(np.arange(h.shape[1])[None,:]<bl[0]-50))
for msk,(x,y,w,hh),p in [(mb,bb,'pA'),(mw,bw,'pB'),(ml,bl,'pC')]:
    print(p,x,y,w,hh); msk=cv2.morphologyEx(msk,cv2.MORPH_CLOSE,np.ones((25,25),np.uint8))
    im=warp_into(im,rgba(f'd/{p}.png'),[(x,y),(x+w,y),(x+w,y+hh),(x,y+hh)],msk)
save('rf-posters',im,875/422,w=True)
save('rf-family',cv2.imread('s14.png'),875/446,w=True)
save('rf-billboard',cv2.imread('rf-billboard.png'),875/525,0,w=True)
save('rf-tote',cv2.imread('rf-tote.png'),875/604,0,w=True)
