# iPayBTC animation: everything in one place

Status on Nov 13, 2026: **paused** by Leo. Nothing is running, and no credits are being spent.
Magnific credits: about 13,355 of 20,000 left. About 6,650 have gone on iPayBTC.

Design board with all the animation work: https://claude.ai/artifact/8jYzc5ke2Hpq5jVxjYcYrB

## Your direction (the brief to build from)

Your own 5-frame storyboard: `/mnt/project-files/kora/ipaybtc/storyboard/storyboard.svg`

1. The coin icon (the tilted iPayBTC icon) blobs out with a soft overshoot, then rolls. The wordmark slides out neatly on one baseline. The background is the animated brand-guide gradient.
2. The coin moves first. The camera zooms in as it jumps into the a, then pans right to the b, and never zooms back out or stops.
3. Two coins run in from the left and knock the first coin, which nearly tips over. Thin white outline, as in the storyboard.
4. "We're reimagining how money moves — open, borderless, and owned by the people", with a warm photo inside the coin shape.
5. The woman (storyboard model, blue top) holding her phone, with the UI popping out of the phone as she pays.
6. 3D: the coin tilting and moving over the phone with the screen live; the gift box opening with coins spilling out.

Motion rules:
- Moves of about 0.6 to 0.9 seconds with a strong ease-out. Short holds, only where you need to read.
- Beats overlap so the motion never stops.
- Everything centred. No wobble, no generic bounces, no fades.
- About 20 to 25 seconds in total.
- One consistent visual world, not mixed styles.

References:
- [Visa video](https://www.youtube.com/watch?v=FMpMOjuHauQ)
- [Claude video](https://x.com/claudeai/status/2118403114890137895)
- [Your Magnific taste collection](https://www.magnific.com/user/collection?id=7970487)
- Motion breakdowns of both videos: `~/Documents/Koraa/ipaybtc/refs/superprompts.md` (on your Mac)

## Versions made (newest first)

| Version | What it was | Your verdict | Where |
|---|---|---|---|
| Film v2 (50s, 4K) | All notes applied, mixed vector, photo and 3D | "Bad, horrible": too slow, mixed looks | [Preview](https://claude.ai/artifact/5mBSCu2jeTVWoApt9QfEFa) · Mac: `~/Documents/Koraa/ipaybtc/ipaybtc-film-v2-4k.mp4` |
| Film v1 (23s) | First build from your storyboard | Too fast, letters jumped, flat screens | [Preview](https://claude.ai/artifact/Nqz768ijHooa4WeFMqoiVc) · Mac: `ipaybtc-film-v1.mp4` |
| Thumbnail final (12.9s) | Mac-made 3D stills, walnut table, crossfades | "Rubbish" | Mac: `ipaybtc-thumbnail-final.mp4` |
| **3D first cut (20s)** | Coin splits into BTC, USDT, USD and NGN; coins sweep onto a round table by a phone; push-in; gift box opens | **Loved the look** (lighting, texture, pale yellow) | Magnific project "iPayBTC thumbnail", "iPayBTC thumbnail first cut" · Mac: `v2/cloud3d/` |

## Assets

- 4K stills (Nano Banana 2.1 with the Surgepay reference) are in the Magnific project "iPayBTC thumbnail": the oval coin, the coin row (cleaned), brand objects, the phone on the table, and the gift box. Previews are in `/mnt/project-files/kora/ipaybtc/looks/` and `first-cut/`.
- Brand package: `/mnt/project-files/kora/ipaybtc/iPayBTC-v4-case-study/` (logo, colours, coins, 74 app screens).
- The woman's stills and clip: Mac `~/Documents/Koraa/ipaybtc/v2/woman/`.
- Stock photos (market scene and carousel): Mac `~/Documents/Koraa/ipaybtc/v2/stock/`.

## What went wrong (lessons)

- AI video warps objects (swapped coin symbols, a broken check mark). That's why the phone screen never sat right.
- Mixing vector, photos, cut-outs and AI 3D made it look like a slideshow.
- The pacing swung from too fast (v1) to too slow (v2).
- Full films were rendered before you approved key frames.

## Next time

- Pick ONE look.
- Do the 3D in Blender: a real phone with its screen built in, and real coins styled after the stills you liked. Blender costs no credits.
- Show you 4 to 6 stills and a timing test before any full render.
- Ask before spending any credit.
- Possibly use Claude Motion (Team or Enterprise plans) for the vector part.
