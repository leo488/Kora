import cv2,numpy as np
def warm(img, k=1.0):
    f=img.astype(np.float32)/255
    f=np.power(f,1-0.14*k)                  # brighter exposure
    f=0.035*k+f*(1-0.035*k)                 # lift blacks
    L=(0.299*f[...,2]+0.587*f[...,1]+0.114*f[...,0])[...,None]
    f=f+k*np.array([-0.045,0.008,0.045],np.float32)*(L**0.8)   # warm highlights (BGR)
    f=f+k*np.array([0.0,0.006,0.012],np.float32)*(1-L)          # warm shadows
    g=(0.299*f[...,2]+0.587*f[...,1]+0.114*f[...,0])[...,None]
    f=g+(f-g)*(1+0.06*k)
    return (np.clip(f,0,1)*255+0.5).astype(np.uint8)
