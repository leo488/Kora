# iPayBTC app v4 — case study package

Everything needed to build the iPayBTC v4 case study on the Koraa Studios website, with animated screens.

- **Client:** iPayBTC, a Bitcoin-first app for Nigeria (buy, sell, send and receive Bitcoin with Naira; P2P; bills).
- **Studio:** Koraa Studios.
- **v4 in one line:** every screen reworked against the iPayBTC brand guide and patterns from the crypto apps people already trust, in a light app with a Deep Navy header, real coin artwork and a motion system.

> **Before you start:** put the brand guide PDF in `brand-guide/` as `iPayBTC-Brand-Guide-v0.1.pdf`. It's too large to ship inside this zip. `brand-guide/brand-guide.md` has all its text, colours and rules.

## What's in this folder

| Path | What it is |
|---|---|
| `README.md` | This brief. |
| `brand-guide/brand-guide.md` | The brand guide's text, colours, type and logo rules. Add the PDF here for the images. |
| `research.md` | Products studied (Base, Coinbase, Phantom, Trust Wallet, Bitnob, OKX, Binance and others), Mobbin links, what each does well and what v4 takes. |
| `tokens.json` | Colours, coin colours, type, radii, sizes and the four design rules. |
| `motion.json` | The 13 motion components (M1–M13): trigger, timing, easing, haptics, which screens use them. |
| `motion/index.html` | All 13 animations running live, each with its spec. Open in a browser. |
| `standalone/index.html` | The whole v4 board (research, system, motion, all screens) as one page. Needs `standalone/assets/`. |
| `screens/*.png` | All 74 phone screens at 2x (780 × 1688). `screens/index.json` maps screen codes to files. |
| `coins/` | Coin artwork as SVG: `btc-3d`, `usdt-3d`, `ngn-3d` (carousel), `*-flat` (lists), plus the pixel avatar. |
| `directions/` | Directions A and B, kept for later (not used in v4). |
| `source/` | The editable Claude Design pages (`IPayBTC App v4.dc.html`, `IPayBTC v4 Directions.dc.html`). |

## Story for the case-study page

1. **Hero.** "Bitcoin for everyday life." Show A2 (navy welcome, pixel field animating, M12) next to C1 (Home). On load: M1 (pixel avatar builds) and M3 (balance digits roll).
2. **The problem.** v3: near-black everywhere, outlined alerts, status pills that stretched, letter tiles instead of real coins, a home with two buttons. Use the "What changed" table in `standalone/index.html` (Research section).
3. **Research.** One card per product with the one thing v4 took. Source: `research.md`.
4. **Choosing a direction.** Three Home directions were tested (A light + Electric Blue, B neutral dark + Yellow, C light + Deep Navy header). C won: it keeps the brand's navy where it matters (who you are, how much you have) and leaves lists and numbers on white. A and B are in `directions/`.
5. **The system.** Brand colours given one job each; Deep Navy primary buttons; Electric Blue for links and selection; yellow only as a highlight. Source: `tokens.json`.
6. **Coins you can swipe.** The signature moment: 3D coins (real Bitcoin mark, Tether ₮, ₦) in a MoonPay-style carousel on Buy and Sell (M13, screens E3 and F2). Animate the swipe with `coins/*-3d.svg`.
7. **Flows.** Click-throughs in a phone mockup (screens push per M11; sheets rise per M5):
   - Sign-up to first buy: A2 → A3 → A4 → A5 → C0 → B1 → B2 → B3 → E3 → E4 → L2
   - Send Bitcoin: C1 → D2 → D3 → D4 → D5
   - P2P buy: F4 → F5 → K2 → K5
   - Log in: J1 → J2 → J3 → J4 → J5, with J6 as the returning-user moment
8. **Motion.** The 13 components looping, each with its spec. Reuse `motion/index.html`.
9. **Feedback states.** Section L: alerts, toasts, banners, status; screens L1–L5.

## Building it

- Mockups: use `screens/*.png`. Device is 390 × 844 pt, 44 pt corner radius. No status bar is painted on the screens; draw the device's own if you want one.
- Motion: rebuild the components in code from `motion.json` instead of recording video. They are squares, transforms and opacity, so they stay sharp at any size. The `@keyframes` in `motion/index.html` are a working reference.
- Respect `prefers-reduced-motion`: replace every motion with a 150 ms fade.
- Use tabular numbers (`font-variant-numeric: tabular-nums`) so digits don't jump when they roll.
- Website headings may use Futura LT Condensed (brand guide, web and campaign headers). The app screens use Neue Haas Grotesk / Inter.

### Brand and design rules that must survive

- Colours only from `tokens.json`.
- Headings in Neue Haas Grotesk (bold, tight), body in Inter. Files use Inter Tight as a stand-in for Neue Haas; swap it in if the licence is available.
- Never redraw, recolour, rotate or add effects to the iPayBTC logo. Use `standalone/assets/ipaybtc-logo-white.png` or the artwork from the brand guide PDF.
- No outlines on alerts, cards or toasts. Status is coloured text with a 6 px square, never a stretched pill.
- No decorative circles. Circles appear only where the thing is round: coins.
- Use the real Bitcoin logo, never a letter stand-in.

## Screen inventory (74)

| Section | Screens |
|---|---|
| A · Welcome and sign-up | A1 Splash, A2 Welcome, A2b Continue with Google, A3 Create account, A4 Verify email, A5 Phone number |
| J · Log in (new) | J1 Log in, J2 Wrong password, J3 Forgot password, J4 New password, J5 Password updated, J6 Quick unlock |
| B · Verification | B1 Verify to buy, B2 Tier 1 NIN, B3 Tier 1 is live, B4 Tier 2 BVN, B5 Selfie prep, B6 Selfie camera, B7 Screening, B8 Tier 2 active |
| C · Home and wallets | C1 Home, C0 Home new user, C2 Wallet tab, C3 Bitcoin, C3b Stablecoin, C4 Naira, C5 Activity, C6 Receipt |
| D · Receive and send | D1 Receive, D1b Address copied, D2 Recipient, D3 Amount, D4 Confirm, D5 Sent |
| E · Buy | E1 How to buy, E2 P2P locked, E3 Amount with coin carousel, E4 Confirm, E5 Over limit, E6 Bank transfer |
| F · Sell, P2P, Swap | F1 How to sell, F2 Amount with coin carousel, F3 Confirm, F4 P2P offers, F5 Pay merchant, F6 Cancelled, F7 Swap |
| K · My orders (new) | K1 Instant list, K2 P2P list, K3 Instant order, K4 P2P release, K5 P2P completed, K6 Empty |
| G · Explore and bills | G1 Explore, G2 Airtime, G3 Data, G4 Confirm, G5 Done, G6 Electricity, G7 Token, G8 Sat converter |
| H · Merchant P2P | H1 Become a merchant, H2 Profile, H3 Create offer, H4 Review, H5 My offers |
| I · Profile | I1 Profile, I2 Verification, I3 Settings |
| L · Feedback (new) | L1 Toast in context, L2 Success, L3 Failed, L4 Rate changed, L5 Offline |

## Open items

- The pixel avatar style is still to be refined against the brand guide's home sample.
- Lockout after wrong passwords (J2, 30 min) and the 4-digit PIN (J6) are placeholders to confirm with iPayBTC.
- Tier limits, swap scope, merchant requirements and the partner bank are carried over from v3 for confirmation.
- All amounts, names and offer data are illustrative.

## Credits

Research references on Mobbin (links in `research.md`) and Bitnob's redesign announcement were studied for patterns only; no third-party UI or artwork is reproduced. The Bitcoin and Tether marks identify the assets the app supports.
