import re,sys
sys.path.insert(0,'.'); from icons import ICONS as I
S='/tmp/claude-0/-home-user/35e05b9f-49fb-5ede-90fa-439510635681/scratchpad'
V=S+'/v2'
lock=re.sub(r'<\?xml[^>]*>','',open('/mnt/project-files/kora/refreeg/figma/lockup.svg').read())
mark=open(S+'/tools/mark-white.svg').read()
def ic(n,s,extra=''): return f'<span style="display:inline-block;width:{s}px;height:{s}px;vertical-align:middle;flex:none;{extra}">{I[n]}</span>'
def L(w,col): return f'<div class="lock" style="width:{w}px;color:{col}">{lock}</div>'
css=f'''@font-face{{font-family:Rec;src:url("{S}/recoleta/Recoleta-Font/OTF/Recoleta Regular.otf")}}
@font-face{{font-family:Geist;src:url("{S}/geist/package/dist/fonts/geist-sans/Geist-Regular.woff2");font-weight:400}}
@font-face{{font-family:Geist;src:url("{S}/geist/package/dist/fonts/geist-sans/Geist-Medium.woff2");font-weight:500}}
@font-face{{font-family:Geist;src:url("{S}/geist/package/dist/fonts/geist-sans/Geist-SemiBold.woff2");font-weight:600}}
*{{margin:0;box-sizing:border-box}} body{{background:transparent;font-family:Geist}} .lock svg{{width:100%;height:auto;display:block}}
.p{{position:relative;overflow:hidden;margin-bottom:40px}} .rec{{font-family:Rec;font-weight:400}}
.mark svg{{width:100%;height:auto;display:block}}'''
B='#0A3CB5';INK='#0E1B14';C='#F0EEE9';LIME='#CFF454';SKY='#9DB6FF'
P=[]
# 1 logo
P.append(f'<div id="logo" class="p" style="width:3840px;height:1961px;background:{B};display:flex;align-items:center;justify-content:center">{L(1500,C)}</div>')
# 3b man card
P.append(f'''<div id="p3b" class="p" style="width:2400px;height:2561px;background:{INK}">
<div style="position:absolute;left:440px;top:350px;right:0;bottom:0;background:{C};border-radius:60px 0 0 0;overflow:hidden">
<div style="height:420px;display:flex;align-items:center;gap:56px;padding-left:120px;background:#fff">
<div style="width:250px;height:250px;border-radius:50%;background:{B};display:flex;align-items:center;justify-content:center"><div class="mark" style="width:150px">{mark}</div></div>
<div style="font-family:Geist;font-weight:500;font-size:118px;letter-spacing:-2px;color:{INK}">Refreeg</div></div>
<div style="position:absolute;top:420px;left:0;right:0;bottom:0;background:url('{V}/s03b.png') center 30%/cover"></div></div></div>''')
# 6b receipt card
P.append(f'''<div id="p6b" class="p" style="width:2400px;height:2694px;background:{SKY};text-align:center;color:{INK}">
<div style="position:absolute;left:0;right:0;top:330px;display:flex;justify-content:center;gap:0">
<div style="width:820px;height:820px;transform:rotate(-8deg) translate(60px,40px)">{I['wallet']}</div>
<div style="width:520px;height:520px;transform:rotate(12deg) translate(-90px,330px)">{I['coin']}</div></div>
<div class="rec" style="position:absolute;left:0;right:0;top:1460px;font-size:200px;line-height:1.02;letter-spacing:-4px">Every naira,<br>receipted.</div>
<div style="position:absolute;left:50%;transform:translateX(-50%);top:1990px;background:#fff;border-radius:999px;padding:44px 96px;font-weight:500;font-size:64px">See the ledger</div></div>''')
# 7 subway poster
row=lambda a,n1,b,n2: f'<div style="display:flex;align-items:center;gap:40px;white-space:nowrap">{ic(n1,200)}<span>{a}</span>{ic(n2,200,"margin-left:30px")}<span>{b}</span></div>'
P.append(f'''<div id="p7" class="p" style="width:2900px;height:2110px;background:{B};color:{C};padding:150px 170px">
<div class="rec" style="font-size:232px;line-height:1.1;letter-spacing:-4px;display:flex;flex-direction:column;gap:70px;margin-top:60px">
{row('Campaigns','heart','Petitions','flag')}{row('Bounties','trophy','Wallet','wallet')}
<div style="display:flex;align-items:center;gap:40px">{ic("pencil",200)}<span>Writer</span></div></div>
<div style="position:absolute;left:176px;bottom:150px;font-weight:500;font-size:70px;line-height:1.3">Every naira, receipted.</div>
<div style="position:absolute;right:170px;bottom:150px">{L(720,C)}</div></div>''')
# 13 posters
def poster(id,bg,fg,inner):
    return f'<div id="{id}" class="p" style="width:1160px;height:1760px;background:{bg};color:{fg}">{inner}<div style="position:absolute;left:90px;bottom:90px">{L(330,fg)}</div><div style="position:absolute;right:90px;bottom:96px;width:330px;font-weight:500;font-size:30px;line-height:1.3;text-align:right">Every kobo.<br>Accounted for.</div></div>'
P.append(poster('pA',B,C,f'<div class="rec" style="position:absolute;left:90px;top:100px;font-size:200px;line-height:.98;letter-spacing:-4px">Every<br>naira,<br>receipted.</div>'))
P.append(poster('pB',C,INK,f'<div style="position:absolute;left:150px;top:220px;width:520px;height:520px;transform:rotate(-8deg)">{I["heart"]}</div><div style="position:absolute;left:560px;top:560px;width:400px;height:400px;transform:rotate(10deg)">{I["flag"]}</div><div style="position:absolute;left:250px;top:900px;width:380px;height:380px;transform:rotate(-4deg)">{I["trophy"]}</div>'))
P.append(poster('pC',LIME,INK,f'<div class="rec" style="position:absolute;left:90px;top:100px;font-size:200px;line-height:.98;letter-spacing:-4px">Give<br>where<br>you can<br>see.</div>'))
# 9a social post
P.append(f'''<div id="p9a" class="p" style="width:2400px;height:2444px;background:{INK}">
<div style="position:absolute;left:380px;top:250px;width:1640px;height:1944px;background:#fff;border-radius:40px;overflow:hidden">
<div style="height:200px;display:flex;align-items:center;gap:32px;padding:0 64px">
<div style="width:96px;height:96px;border-radius:50%;background:{B};display:flex;align-items:center;justify-content:center"><div class="mark" style="width:58px">{mark}</div></div>
<div style="font-weight:600;font-size:50px;color:{INK}">refreeg</div><div style="margin-left:auto;font-size:70px;color:{INK};letter-spacing:6px">···</div></div>
<div style="position:absolute;top:200px;left:0;right:0;height:1544px;background:{B}">
<div class="rec" style="position:absolute;left:80px;top:60px;font-size:180px;line-height:1;letter-spacing:-4px;color:{C}">Give where<br>you can see.</div>
<div style="position:absolute;left:80px;right:80px;top:500px;bottom:80px;border-radius:36px;background:url('{V}/s09a.png') center 40%/cover"></div>
<div style="position:absolute;right:30px;top:390px;width:260px;height:260px;transform:rotate(10deg)">{I['heart']}</div></div>
<div style="position:absolute;bottom:0;left:0;right:0;height:200px;display:flex;align-items:center;gap:56px;padding:0 64px">
<svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="{INK}" stroke-width="1.8"><path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/></svg>
<svg width="76" height="76" viewBox="0 0 24 24" fill="none" stroke="{INK}" stroke-width="1.8"><path d="M20 12a8 8 0 1 1-3.2-6.4L20 4v5h-5"/></svg>
<svg width="76" height="76" viewBox="0 0 24 24" fill="none" stroke="{INK}" stroke-width="1.8"><path d="M21 3 3 10l7 3 3 7z"/></svg>
<svg style="margin-left:auto" width="76" height="76" viewBox="0 0 24 24" fill="none" stroke="{INK}" stroke-width="1.8"><path d="M6 3h12v18l-6-4-6 4z"/></svg></div></div></div>''')
# 15 type plate
P.append(f'''<div id="p15" class="p" style="width:3840px;height:1920px;background:{B};color:{C};text-align:center">
<div class="rec" style="position:absolute;left:0;right:0;top:230px;font-size:470px;line-height:1.02;letter-spacing:-10px">Give where<br>{ic('heart',400,'margin:0 40px 0 0;transform:rotate(-8deg) translateY(-30px)')}you can see.</div>
<div style="position:absolute;left:0;right:0;bottom:150px;font-weight:500;font-size:64px;line-height:1.35">Verified campaigns, petitions and paid bounties,<br>with a receipt for every naira.</div></div>''')
# 12b phone on lime
P.append(f'''<div id="p12b" class="p" style="width:2400px;height:2489px;background:{LIME}">
<div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:1060px;height:2004px;border-radius:90px;overflow:hidden;background:url('/mnt/project-files/kora/refreeg/figma/app-pledge-x4.png') top/100% auto #fff"></div></div>''')
# chips
def chip(id,icon,t,a,tm):
    return f'''<div id="{id}" style="display:inline-flex;align-items:center;gap:34px;background:#fff;border-radius:28px;padding:30px 44px 30px 30px;width:1180px;margin:20px">
<div style="width:120px;height:120px;border-radius:24px;background:{INK};padding:16px;flex:none">{I[icon]}</div>
<div style="flex:1;color:{INK}"><div style="font-weight:500;font-size:44px;line-height:1.2;letter-spacing:-.3px">{t}</div><div style="font-size:44px;line-height:1.2;margin-top:4px;color:#3a463f">{a}</div></div>
<div style="align-self:flex-start;font-size:32px;color:#6b746e">{tm}</div></div>'''
P.append('<div style="background:transparent">'+chip('c6','heart','Restock 600 market stalls','₦12.4M of ₦20M','10:23')+chip('c9','coin','Fire safety kits, Balogun','₦1.4M of ₦4M','13:41')+chip('c12','flag','School fees for 90 girls','₦5.5M of ₦5.8M','14:55')+'</div>')
# 8 phone mark & 3a icon
P.append(f'<div id="mk" style="width:800px;height:800px;background:transparent;display:flex;align-items:center;justify-content:center"><div class="mark" style="width:800px">{mark}</div></div>')
open(V+'/d/plates.html','w').write(f'<!doctype html><html><head><meta charset="utf-8"><style>{css}</style></head><body>{"".join(P)}</body></html>')
