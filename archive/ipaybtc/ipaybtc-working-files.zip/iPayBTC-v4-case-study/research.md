# iPayBTC v4 — Research notes

Sources: Mobbin (iOS screens, Nov 2026), Bitnob's own redesign announcement, and the iPayBTC Brand Guide v0.1.
All Mobbin references are iOS. Links open on Mobbin (account needed).

## Products studied

| Product | Why it's here | What we looked at |
|---|---|---|
| Base (Coinbase's onchain app) | Named by the client; strongest blue-led crypto UI | Home, onboarding, sign-in, receive, send keypad |
| Coinbase | The "other blue one"; largest regulated crypto app | Home (light + dark), transactions, sign-in, in-app error alert |
| Phantom | Best-in-class wallet motion and states | Home, send flow, buy keypad, success screen |
| Trust Wallet | Large blue self-custody wallet | Transaction history |
| Bitnob | African Bitcoin app, same market as iPayBTC | Redesign announcement (not on Mobbin) |
| OKX | P2P marketplace and order management | P2P offers, P2P orders, sign-in, KYC intro |
| Binance | P2P marketplace, instant buy, sign-in | P2P offers, instant order keypad, open orders, sign-in |
| Cash App | Balance privacy and money actions | Home with hide-balance |
| MoonPay, PayPal, Public | Buy-crypto amount entry | Buy keypads with preset amounts |
| Crypto.com | Dense status history | Transaction history |
| Solflare, PayPal, Public | Receive patterns | QR, network, warnings |
| Zopa, Chime, Careem | Identity verification progress | KYC steps |
| Wealthsimple, Brave | Calm sign-in | Login, unlock |

## Mobbin references

- Base home, empty: https://mobbin.com/flows/56be3263-eb70-4813-a772-98aa3dd56064 (Onboarding flow, 11 screens)
- Base receive with QR + copy toast: https://mobbin.com/screens/f59bdad5-e979-49fa-9222-a94c161a4144
- Coinbase home (light): https://mobbin.com/screens/fac68d02-2750-4ee8-9f41-768f9121be14
- Coinbase home (dark): https://mobbin.com/screens/f46e9495-7503-400d-b753-9c2ea4bd8b3b
- Coinbase in-app error alert: https://mobbin.com/screens/f731ec39-f24f-4782-9fb6-01e72854d98b
- Coinbase transactions: https://mobbin.com/screens/095bdf78-41c1-400c-8fd2-9db894e5568b
- Coinbase sign-in: https://mobbin.com/screens/879f1965-037e-43ec-a42c-abbb137c5dd8
- Phantom home: https://mobbin.com/screens/575c3602-b594-4946-951d-8386d1fb8aca
- Phantom send flow (8 screens): https://mobbin.com/flows/c2d6e24f-a4d6-4030-ac19-b626fecdf5b4
- Phantom buy keypad: https://mobbin.com/screens/e98d7eca-2374-4264-9a66-d53de7d4130c
- Trust Wallet history: https://mobbin.com/screens/33ccda7e-9c7c-43b1-946d-35f8c894749f
- OKX P2P offers: https://mobbin.com/screens/d9db9b94-0f28-4f6d-af76-95329f9c1c70
- OKX P2P orders: https://mobbin.com/screens/48eed82e-300c-4939-8261-8330ff6fc7da
- OKX sign-in: https://mobbin.com/screens/8724eae0-1e18-4f93-9067-d6ce3f992073
- OKX KYC intro: https://mobbin.com/screens/2906b0e3-ac7a-496a-91e2-6097efe01a15
- Binance P2P offers: https://mobbin.com/screens/5e4a9d21-618b-4445-9b9f-f23d3a82da22
- Binance instant order: https://mobbin.com/screens/b15ab66c-72c7-4520-8e7b-e0a384ef4012
- Binance open orders: https://mobbin.com/screens/404a678e-decd-42c0-9812-a14f3126e1cc
- Binance sign-in: https://mobbin.com/screens/f75cd0c2-196c-4e2e-aa81-bb54e900d531
- Cash App home: https://mobbin.com/screens/18b40898-3971-46f3-9604-f1b875183119
- MoonPay buy: https://mobbin.com/screens/e56ac66b-90e4-4954-843f-169a95e31695
- PayPal buy Bitcoin: https://mobbin.com/screens/a2511c63-f271-49c5-b9f5-a702115046e4
- Public buy BTC: https://mobbin.com/screens/e51a7c93-7bed-4714-b36b-4ec37b793d14
- Crypto.com history: https://mobbin.com/screens/b8af4c01-88c6-4a4a-9c47-9a9281278fd5
- PayPal receive: https://mobbin.com/screens/4320e80a-afa6-44dc-a9a6-317ad8a44a24
- Public receive BTC: https://mobbin.com/screens/f1d60453-f208-4d5b-8244-4a2c7d117fa7
- Solflare receive: https://mobbin.com/screens/cab7112b-0cdb-4135-a50e-072424e0ab69
- Zopa verification: https://mobbin.com/screens/4c4d4309-676c-47d8-9b99-2c7f0be280e0
- Chime sign-up steps: https://mobbin.com/screens/1fac87e2-445a-4478-84ca-0d01edc25b38
- Wealthsimple login: https://mobbin.com/screens/63013d5e-6242-4809-9b00-63fa7502dee7

Bitnob: https://www.bitnob.com/blog/bitnob-unveils-its-new-look

## What the leaders do (and what v4 takes)

### Home
- **Balance is the hero, stated once, very large.** Coinbase, Base, Phantom and Cash App all lead with one number at 40–56px. Phantom adds the day's change as both an amount and a % pill. → v4: one big balance, change line under it in words ("Your Bitcoin is up 4.6% today", from the brand guide).
- **Hide balance is one tap.** Cash App puts an eye icon on the balance; Bitnob made show/hide a headline feature of its redesign. → v4: "Tap to hide balance" on the balance itself (brand guide copy), with an eye control.
- **Four actions as equal tiles.** Base (Buy, Trade, Send, Request) and Phantom (Receive, Send, Swap, Buy) use four same-size tiles, icon over label. v3 had two buttons. → v4: four tiles: Buy, Sell, Send, Receive.
- **Identity up top.** Base and Phantom show the user's avatar and handle at top-left, not a generic "Your Account" label. → v4: pixel avatar + @handle + greeting.
- **Promos are dismissible cards, one at a time.** Coinbase and Base both put a single earn/referral card with an X under the actions. → v4: the verification prompt uses the same slot, dismissible, one at a time.
- **Bitnob puts fiat and BTC balances on Home** so users don't open the Wallet tab to see them. → v4: Home shows the three wallets as a compact row.

### Amount entry (buy, sell, send)
- **Huge centered number + full keypad.** Base, Phantom, MoonPay, PayPal, Binance. The converted amount sits directly under it with a swap-units control.
- **Preset amounts.** PayPal ($20/$50/$100/$500), Public, Binance (Min/$50/Max). → v4: ₦5k/₦10k/₦20k/Max chips above the keypad.
- **Pay-with row above the keypad, CTA pinned.** Phantom puts Review directly above the keypad; Base puts recipient + total in a footer. → v4: pay-with row + pinned Review.
- **Say what's available.** Phantom: "Available to send … Max". → v4: available + limit in one line.

### Lists and orders
- **Status is text in colour, not a big pill.** Coinbase ("Pending"), Crypto.com ("Processed", "Order Cancelled"), OKX ("Pending release"). Trust Wallet uses a small check badge. v3's stretched pills were the problem the client flagged. → v4: status as coloured text with a 6px square pixel marker.
- **Group by date.** Trust Wallet, Crypto.com. → kept.
- **Orders split by state first.** OKX: Pending / Completed tabs, then All / In progress / In dispute chips. → v4: Instant / P2P switch, then Active / Completed / Cancelled.

### P2P
- **Merchant card anatomy is settled across OKX and Binance:** name + verified mark, trade count, completion %, big price, available + limits, payment methods, time limit, one Buy button. → v4 adds the time limit and completion % that v3 lacked.

### Receive
- **QR in a card with the wallet name and short address, Copy + Share as equal buttons** (Solflare, Base). Base drops the user's avatar in the QR centre. → v4: QR with the iPayBTC oval mark in the centre.
- **Network is a visible, changeable row** (PayPal). → v4: On-chain / Lightning segmented.
- **Warn before irreversible things** (Public's "Important things to know"). → v4: one line, not a wall.
- **Copy confirmation is a toast** (Base). → v4 toast.

### Sign-in
- **One task per screen, one primary button.** Base splits email and passkey; Coinbase and Wealthsimple keep only email, password, forgot link, Continue. OKX/Binance add social buttons below an "or" rule. → v4: email, password with show toggle, Forgot, Log in, Google below.
- **Returning users skip the form:** Brave's "Unlock wallet". → v4 J6 PIN/Face ID unlock.

### Verification
- **Show the whole path and where you are** (Chime 3-step header, OKX numbered checklist, Zopa progress bar). → v4: 3-step tier ladder on every KYC screen.

### Feedback
- **Coinbase's in-app alert is a filled amber block, no outline**, title + one line. Matches the client's "no outlines" note. → v4 alerts: tinted fills only.
- **Success = one colour field, one icon, one sentence, one button** (Phantom "Sent!"). → v4 success screens.

## Brand guide constraints (iPayBTC Brand Guide v0.1)
- Deep Navy #050E7F — dominant background for product UI.
- Electric Blue #0A31F5 — highlights, accents, major UI elements.
- Milky Bitcoin Yellow #FFF778 — max contrast on navy; emphasis and celebratory states.
- Deep Blue #040246 — night mode, overlays, premium moments.
- Extended: Bitcoin Orange #FF8A00 (sparingly), Sky Blue #4DA3FF / #88C2ED, Cream #F5E27A, Gold #F5BF0F.
- "Brutalist but clean": soft colours, bold structure, large type, generous spacing.
- Type: Neue Haas Grotesk (headings, tracking −10), Inter (body, tracking 0).
- Icon: tilted oval coin in motion. Never redrawn, recoloured or given effects.
- Home sample copy: "@Fadare!", "Good afternoon, Fadare", "Your Bitcoin is up 4.6% today", "$176,000.00", "0.000000565 BTC", "Tap to hide balance".

## Client notes carried into v4
- No outlines on alerts, cards and toasts.
- Status tags must not stretch.
- No decorative circles: shapes must mean something. Squares (pixels) for avatars, status and progress; circles only for coins.
- Use the real Bitcoin logo, not a letter stand-in; Tether ₮ for Stablecoin.
- Keep the live app's bottom navigation: Home, P2P, Explore, Wallet, Profile.
- Coin carousel on Buy/Sell, after MoonPay's buy screen (https://mobbin.com/screens/e56ac66b-90e4-4954-843f-169a95e31695).

## Direction chosen
Three Home directions were tested: A light + Electric Blue (Coinbase/Base-like), B neutral dark + Yellow (Phantom-like), C light + Deep Navy header. v4 uses C. A and B are saved in `directions/`.
