# iPayBTC case study: Magnific scene prompts

Model: Nano Banana 2.1, 4K. For each scene, attach the reference listed and the artwork file from this folder.
Brand colours: Electric Blue #0A31F5, Deep Navy #050E7F, Milky Yellow #FFF778. No other accent colours.

## 1. Woman with card and phone (studio)
Reference: Yuri Arcurs "happy woman credit card phone studio" (43654317).
Prompt: Bright studio portrait of a happy young Nigerian woman holding an Electric Blue (#0A31F5) bank card in one hand and a smartphone in the other, big natural smile, plain soft milky yellow (#FFF778) studio backdrop, soft even light, sharp focus, commercial photography, clean, no text on the background. Card front is plain Electric Blue with a small white logo area at the top left.

## 2. Friends selfie
Reference: friends selfie (68366904).
Prompt: Three young African friends taking a selfie together outdoors in a sunny city street in Lagos, laughing, one wearing an Electric Blue (#0A31F5) tee, natural daylight, candid, shallow depth of field, editorial photography, clean background, no logos or text.

## 3. Road trip, friends by the car
Reference: portrait smiling female friends by car (368253179).
Prompt: Two smiling young African women leaning on a car on a road trip, one holding a smartphone showing a light app screen, golden hour light, open road behind, warm but natural colours, one wearing Electric Blue (#0A31F5), editorial lifestyle photography, sharp, no logos or text.

## 4. Beach at sunset
Reference: friends summer sunset beach (63150531).
Prompt: Group of young African friends on a beach at sunset, relaxed and happy, one person holding a phone, soft golden light, clean horizon, natural colours with one Electric Blue (#0A31F5) piece of clothing, editorial photography, no logos or text.

## 5. Sidewalk billboard with bench
Reference: sidewalk billboard mockup with bench (426154960). Artwork: billboard-sidewalk.png.
Prompt: Long street hoarding billboard on a city sidewalk with a wooden bench in front at the lower right and a young tree beside it, afternoon sun with soft tree shadows across the board, the billboard shows the attached artwork exactly, flat and unchanged, photoreal, sharp, straight-on view.

## 6. Tote bag
Artwork: tote.png.
Prompt: Young African woman in a bright studio carrying an Electric Blue (#0A31F5) canvas tote bag over her shoulder, the tote shows the attached print exactly, plain off-white background, soft light, cut-out editorial look, photoreal, sharp.

## 7. Bus-stop posters
Artwork: poster-own-it.png, poster-move-freely.png, poster-gradient-logo.png.
Prompt: Modern city bus shelter with a backlit portrait poster panel showing the attached artwork exactly, evening light, clean street, photoreal, sharp, straight-on view.

## 8. OTP illustration
Reference: Magnific OTP vector illustration (427709496).
Prompt: Flat vector illustration in the same style as the reference: a hand holding a phone showing a one-time code screen, a shield and check mark, using only Electric Blue (#0A31F5), Deep Navy (#050E7F), Milky Yellow (#FFF778) and white, clean shapes, no outlines, no extra colours, plain white background.
