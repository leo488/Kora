INK='#0E1B14'
def sticker(col, sil, lines, extra=''):
    return f'''<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" style="overflow:visible;width:100%;height:100%;display:block">
<g fill="{col}" stroke="{col}" stroke-width="16" stroke-linejoin="round" stroke-linecap="round">{sil}</g>
<g fill="none" stroke="{INK}" stroke-width="4.6" stroke-linecap="round" stroke-linejoin="round">{lines}</g>{extra}</svg>'''
H='M50 86 C22 66 8 50 10 33 C12 19 23 12 34 13 C42 14 47 19 50 25 C53 19 58 14 66 13 C77 12 88 19 90 33 C92 50 78 66 50 86Z'
heart=sticker('#9DB6FF',f'<path d="{H}"/>',f'<path d="{H}"/><path d="M19.5 38 C19.5 31 23 26.5 28.5 25.5"/><path d="M35 55 q4 -4.5 7.5 0 t7.5 0 t7.5 0 t7.5 0"/>')
F='M24 22 C40 15 52 28 78 20 C75 32 75 44 80 56 C56 64 42 52 24 60'
flag=sticker('#CFF454',f'<path d="{F}Z"/><path d="M22 16 L22 92"/><circle cx="22" cy="14" r="5"/>',f'<path d="{F}"/><path d="M22 18 L22 92"/><path d="M36 39 q3.5 -4 7 0 t7 0 t7 0 t7 0"/>','<circle cx="22" cy="14" r="5.5" fill="#0E1B14"/>')
CUP='M30 18 H70 V38 C70 52 61 60 50 60 C39 60 30 52 30 38Z'
STAR='M50 26 L53.5 33.5 L61.5 34 L55.3 39.2 L57.3 47 L50 42.7 L42.7 47 L44.7 39.2 L38.5 34 L46.5 33.5Z'
trophy=sticker('#F4C95D',f'<path d="{CUP}"/><path d="M30 24 H20 C14 24 14 42 32 46"/><path d="M70 24 H80 C86 24 86 42 68 46"/><rect x="33" y="70" width="34" height="14" rx="3"/><path d="M44 60 V70 M56 60 V70"/>',
 f'<path d="{CUP}"/><path d="M30 24 H22 C16 24 16 40 32 44"/><path d="M70 24 H78 C84 24 84 40 68 44"/><path d="M45 60 L43 70 M55 60 L57 70"/><rect x="33" y="70" width="34" height="13" rx="3"/>',
 f'<path d="{STAR}" fill="#0E1B14"/>')
wallet=sticker('#9FD8B8','<path d="M26 32 L58 20 L64 32Z"/><rect x="16" y="32" width="66" height="48" rx="8"/><rect x="62" y="48" width="22" height="16" rx="6"/>',
 '<path d="M28 32 L57 21 L63 32"/><rect x="16" y="32" width="64" height="48" rx="8"/><rect x="64" y="48" width="20" height="16" rx="6"/><path d="M26 66 q3.5 -4 7 0 t7 0 t7 0"/>','<circle cx="72" cy="56" r="3.2" fill="#0E1B14"/>')
P='M24 84 L30 66 L68 28 C72 24 78 24 82 28 C86 32 86 38 82 42 L44 80Z'
SP='M24 14 Q26 24 34 26 Q26 28 24 38 Q22 28 14 26 Q22 24 24 14Z'
pencil=sticker('#FF9A6E',f'<path d="{P}"/><path d="{SP}"/>',f'<path d="{P}"/><path d="M30 66 L44 80"/><path d="M61 35 L75 49"/><path d="{SP}"/>','<path d="M24 84 L27 75 L33 81Z" fill="#0E1B14"/>')
coin=sticker('#F4C95D','<circle cx="50" cy="50" r="36"/>','<circle cx="50" cy="50" r="36"/><circle cx="50" cy="50" r="24"/><path d="M42 38 V62 M58 38 V62 M42 38 L58 62 M37 47 H63 M37 53 H63"/>')
ICONS=dict(heart=heart,flag=flag,trophy=trophy,wallet=wallet,pencil=pencil,coin=coin)
